package EKPL2.ReUTS;

/**
 * Created by Sheldon on 3/29/2017.
 */
public interface Termometer {
  public void setTemp(double tempInC);
  public double getTemp(char option);
}