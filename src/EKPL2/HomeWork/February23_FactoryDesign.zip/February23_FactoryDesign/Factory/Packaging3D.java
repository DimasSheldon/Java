//package EKPL2.HomeWork.February23_FactoryDesign.Factory;
//
//
//import javax.swing.*;
//import java.awt.*;
//
/**
 * Created by Sheldon on 2/23/2017.
 * A java class to display design of the packaging on JFrame window.
 */
//public class Packaging3D extends JComponent {
//  public void paintComponent(Graphics g) {
//    Graphics2D painter = (Graphics2D) g;
//
//  }
//}