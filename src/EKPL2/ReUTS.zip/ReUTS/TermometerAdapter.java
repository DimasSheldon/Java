package EKPL2.ReUTS;

/**
 * Created by Sheldon on 3/29/2017.
 */

public class TermometerAdapter extends ConvertTermometer implements Termometer {
  private double tempInF;

  public TermometerAdapter() {
    tempInF = 0;
  }

  @Override
  public double convertCtoF(double tempInC) {
    return (tempInC * 9 / 5) + 32;
  }
  public void setTemp(double tempInC) {
    tempInF = convertCtoF(tempInC);
    System.out.println(tempInF);
  }

  public double getTemp(char option) {
    System.out.println(tempInF);
    double result;
    if (option == 'k' || option == 'K') {
      /*debugging
      System.out.println("k " + tempInF);
      System.out.println("conv" + convertFtoK(tempInF));
      */
      result = convertFtoK(tempInF);
    } else if (option == 'r' || option == 'R') {
      System.out.println("r " + tempInF);
      result = convertFtoR(tempInF);
    } else {
      result = 0;
    }
    return result;
  }

  //  public double getTemp(char option) {
//    return convertFtoK(tempInF);
//  }
}